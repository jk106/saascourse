class MoviesController < ApplicationController

  def show
    id = params[:id] # retrieve movie ID from URI route
    @movie = Movie.find(id) # look up movie by unique ID
    # will render app/views/movies/show.<extension> by default
  end

  def index
  	sort = params[:sort]
  	if sort != nil
  		session[:sort] = sort
  	end
  	ratings = params[:ratings]
  	if ratings != nil
  		session[:ratings] = ratings
  	end
  	ratingss = session[:ratings]
  	sorts = session[:sort]
  	if (ratings == nil || sort == nil) && (ratingss != nil && sorts != nil)
  		flash.keep
  		redirect_to movies_path(:ratings => ratingss, :sort => sorts)
  	elsif (ratings == nil || sort == nil) && (ratingss != nil && sorts == nil)
  		flash.keep
  		redirect_to movies_path(:ratings => ratingss, :sort => "0")
  	end 
  	@selected = []
  	if ratings == nil && ratingss == nil
			@selected=Movie::RATINGS
		end
  	@all_ratings=Movie::RATINGS
  	if ratings != nil
  		@conditions = ""
			ratings.each do |k, v|
				@selected.push(k)
  			@conditions << (@conditions.empty? ? "rating = '#{k}'" : " OR rating = '#{k}'") if v == "1"
			end
			if sort == nil
  			@movies = Movie.where(@conditions)
  		elsif sort == "1"
    		@movies = Movie.where(@conditions).order("title")
    	else
    		@movies = Movie.where(@conditions).order("release_date")
    	end
  	elsif sort == nil
  		@movies = Movie.all
  	elsif sort == "1"
    	@movies = Movie.find(:all, :order => "title")
    else
    	@movies = Movie.find(:all, :order => "release_date")
    end
    @title = sort.to_i
  end

  def new
    # default: render 'new' template
  end

  def create
    @movie = Movie.create!(params[:movie])
    flash[:notice] = "#{@movie.title} was successfully created."
    redirect_to movies_path
  end

  def edit
    @movie = Movie.find params[:id]
  end

  def update
    @movie = Movie.find params[:id]
    @movie.update_attributes!(params[:movie])
    flash[:notice] = "#{@movie.title} was successfully updated."
    redirect_to movie_path(@movie)
  end

  def destroy
    @movie = Movie.find(params[:id])
    @movie.destroy
    flash[:notice] = "Movie '#{@movie.title}' deleted."
    redirect_to movies_path
  end

end
