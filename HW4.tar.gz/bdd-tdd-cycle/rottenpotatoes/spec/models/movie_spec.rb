require "spec_helper"

describe Movie do
	it "responds to similar_to" do
		Movie.should respond_to(:similar_to)
	end
	it "has ratings" do
    Movie.all_ratings == %w(G PG PG-13 NC-17 R)
  end
	context "when a movie is passed as argument" do
		let(:movie) {Movie.create(director: 'Scorsese')}
		before(:each) do
			3.times { Movie.create(director: 'Scorsese')}
			2.times { Movie.create(director: 'Hitchcock')}
		end
		
		it "should bring similar movies" do
			Movie.similar_to(movie).should have(4).items
		end
	end
end
